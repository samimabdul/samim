package com.cg.client;

import com.cg.dao.BookDao;
import com.cg.dao.BookDaoImpl;
import com.cg.entities.Book;
import com.cg.service.BookService;
import com.cg.service.BookServiceImpl;

public class client {
	public static void main(String[] args) {

		BookService service = new BookServiceImpl();
		BookDao dao= new BookDaoImpl();
		
		System.out.println("************Listing total number of books*************");
		System.out.println("Total books:"+service.getBookCount());
		Book book=dao.getBookById(182);
		System.out.println(book);
		
}
}
