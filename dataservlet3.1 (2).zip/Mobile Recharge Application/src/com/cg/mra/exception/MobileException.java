package com.cg.mra.exception;

public class MobileException extends Exception {



	public MobileException() {
		// TODO Auto-generated constructor stub
	}

	public MobileException(String string) {
		// TODO Auto-generated constructor stub
	}
}
