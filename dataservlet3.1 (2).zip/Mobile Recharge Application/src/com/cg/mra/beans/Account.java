package com.cg.mra.beans;

public class Account {
	private String accountType;
	private String coustomerName;
	private double accountBalance;
	public Account(String accountType, String coustomerName,double accountBalance) {

		this.accountType=accountType;
		this.coustomerName=coustomerName;
		this.accountBalance=accountBalance;// TODO Auto-generated constructor stub
	}

	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public String getCoustomerName() {
		return coustomerName;
	}
	public void setCoustomerName(String coustomerName) {
		this.coustomerName = coustomerName;
	}
	public double getAccountBalance() {
		return accountBalance;
	}
	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}
	

}
