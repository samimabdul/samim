package com.cg.mra.test;


import junit.framework.Assert;


import com.cg.mra.exception.MobileException;

import org.junit.Test;







import com.cg.mra.exception.MobileException;
import com.cg.mra.service.AccountService;
import com.cg.mra.service.AccountServiceImpl;

public class TestClass {
	@Test(expected=MobileException.class)
	public void test_ValidateName_null() throws MobileException{
		AccountService service=new AccountServiceImpl();
		service.validateCustomerName(null);
	}
	@Test
	public void test_validateName_v1() throws MobileException{
	
		String name="Aete121";
		AccountService service=new AccountServiceImpl();
		boolean result= service.validateCustomerName(name);
		Assert.assertEquals(false,result);
	}
	@Test
	public void test_validateName_v2() throws MobileException{
	
		String name="Amita";
		AccountService service=new AccountServiceImpl();
		boolean result= service.validateCustomerName(name);
		Assert.assertEquals(true,result);
	}
	@Test
	public void test_validateName_v3() throws MobileException{
	
		String name="amita";
		AccountService service=new AccountServiceImpl();
		boolean result= service.validateCustomerName(name);
		Assert.assertEquals(false,result);
	}
	
	@Test(expected=MobileException.class)
	public void test_ValidatemobileNo_null() throws MobileException{
		AccountService service=new AccountServiceImpl();
		service.validatemobileNo(null);
	}
	@Test
	public void test_validatemobileNo_v1() throws MobileException{
	
		String mobileNo="ABCD91828288";
		AccountService service=new AccountServiceImpl();
		boolean result= service.validateCustomerMobNo(mobileNo);
		Assert.assertEquals(false,result);
	}
	@Test
	public void test_validatemobileNo_v2() throws MobileException{
	
		String mobNo="9922974725";
		AccountService service=new AccountServiceImpl();
		boolean result= service.validateCustomerMobNo(mobNo);
		Assert.assertEquals(true,result);
	}
	@Test
	public void test_validatemobileNo_v3() throws MobileException{
	
		String mobNo="992297";
		AccountService service=new AccountServiceImpl();
		boolean result= service.validateCustomerMobNo(mobNo);
		Assert.assertEquals(false,result);
	}
	
		
	}


