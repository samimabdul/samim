package com.cg.mra.service;

import com.cg.mra.beans.Account;

public interface AccountService {
	Account getAccountDetails(String mobileNo);
	int rechargeAccount(String mobileNo, double rechargeAmount);
	
	boolean validateCustomerName(Object object);
	
	boolean validateCustomerMobNo(boolean b);
	void validatemobileNo(Object object);
	boolean validateCustomerMobNo(String mobileNo);
	boolean validateCustomerName(String CustomerName);

}
