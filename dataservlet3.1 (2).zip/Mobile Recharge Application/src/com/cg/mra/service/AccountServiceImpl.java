package com.cg.mra.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.employee.exception.EmployeeException;
import com.cg.mra.beans.Account;
import com.cg.mra.exception.MobileException;

public class AccountServiceImpl implements AccountService {

	@Override
	public Account getAccountDetails(String mobileNo) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int rechargeAccount(String mobileNo, double rechargeAmount) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean validateCustomerName(String CustomerName) {
		 if(CustomerName==null)
	            throw new MobileException("Name can not be null");
	        Pattern pat = Pattern.compile("[A-Z][a-z]{3,12}");
	        Matcher mat= pat.matcher(CustomerName);
	        return mat.matches();
	}

	@Override
	public boolean validateCustomerMobNo(String mobileNo) {
		 Pattern pat = Pattern.compile("[0-9]{10}");
	        Matcher mat= pat.matcher(mobileNo);
	        return mat.matches();
	}

	@Override
	public void validatemobileNo(Object object) {
		// TODO Auto-generated method stub
		
	}

}
