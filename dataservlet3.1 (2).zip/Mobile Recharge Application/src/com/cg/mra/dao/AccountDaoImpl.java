package com.cg.mra.dao;

import java.util.HashMap;
import java.util.Map;



import com.cg.mra.dao.Data;
import com.cg.mra.exception.MobileException;
import com.cg.mra.beans.Account;

public class AccountDaoImpl implements AccountDao {
	Map<String,Account>accountEntry;
	
	public AccountDaoImpl() {
		accountEntry=new HashMap<>();
		accountEntry.put("9010210131",new Account("Prepaid","Vaishali",200));
		accountEntry.put("9823920123",new Account("Prepaid","Megha",453));
		accountEntry.put("9932012345",new Account("Prepaid","Vikash",631));
		accountEntry.put("9010210132",new Account("Prepaid","Anju",521));
		accountEntry.put("9010210133",new Account("Prepaid","Tushar",632));
		// TODO Auto-generated constructor stub
	}

	@Override
	public Account getAccountDetails(String mobileNo) {
		
		Account account= accountEntry.get(mobileNo);
		return account;
	}

	@Override
	public int rechargeAccount(String mobileNo, double rechargeAmount, double accountBalance) throws MobileException {
		Account account=accountEntry.get(mobileNo);
		if(accountEntry.containsKey(mobileNo))
		{
			accountBalance=((Account) accountEntry).getAccountBalance();
		accountBalance=accountBalance+rechargeAmount;
		return (int) accountBalance;
		}
		else
			throw new MobileException();
	}

}
