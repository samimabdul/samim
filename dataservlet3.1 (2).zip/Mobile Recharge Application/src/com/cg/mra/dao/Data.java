package com.cg.mra.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.mra.beans.Account;

public class Data {
		private static Map<String,Account> accountEntry;
	public static Map<String,Account> createCollection(){
		if(accountEntry==null)
			accountEntry=new HashMap<>();
		return accountEntry;
		
	}}
