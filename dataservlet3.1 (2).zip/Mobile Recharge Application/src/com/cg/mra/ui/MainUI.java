package com.cg.mra.ui;

import java.util.Scanner;

import com.cg.mra.beans.Account;
import com.cg.mra.exception.MobileException;
import com.cg.mra.service.AccountService;
import com.cg.mra.service.AccountServiceImpl;



public class MainUI {
	  public static void main(String args[]) throws MobileException{
	        AccountService service=new AccountServiceImpl();
	        Account account;
	        int ch=0;
	        Scanner sc=new Scanner(System.in);
	        do{
	            System.out.println("1. Account Balance Enquiry ");
	            System.out.println("2. Recharge Amount");
	            System.out.println("3. Exit");
	            System.out.println("Enter Your Choice");
	            ch=sc.nextInt();
	            switch(ch)
	            {
	            case 1:
	            	System.out.println("enter your mobile no");
	            	String mobileNo=sc.next();
	            	account=service.getAccountDetails(mobileNo);
	            	if(account==null)
	            	{
	            		System.out.println("account doesn't exist ");
	            	}
	            	else
	            	{
	            		  System.out.println("Name: " + account.getCoustomerName());
	                      System.out.println("Account type: " + account.getAccountType());
	                      
	                      System.out.println("Balance: " + account.getAccountBalance());
	            	}
	            	
	            break;
	            case 2:
	           System.out.println("enter your mobile no ");
	           mobileNo=sc.next();
	           if(service.validateCustomerMobNo(mobileNo!=null))
	           {
	            	
	            }
	        
	        while(ch!=3);
	        {}
	        
}
}}
}