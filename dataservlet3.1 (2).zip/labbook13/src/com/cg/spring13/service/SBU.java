package com.cg.spring13.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Value;

public class SBU {
	@Value(value = "111")
	int SbuId;
	@Value(value = "PESERVICE")
	String sbuName;
	@Value(value="Kiron Rao")
	String sbuHead;
	List<Employee> employeelist;
	
	public List<Employee> getEmployeelist() {
		return employeelist;
	}
	public void setEmployeelist(List<Employee> employeelist) {
		this.employeelist = employeelist;
	}
	public int getSbuId() {
		return SbuId;
	}
	public void setSbuId(int sbuId) {
		SbuId = sbuId;
	}
	public String getSbuName() {
		return sbuName;
	}
	public void setSbuName(String sbuName) {
		this.sbuName = sbuName;
	}
	public String getSbuHead() {
		return sbuHead;
	}
	public void setSbuHead(String sbuHead) {
		this.sbuHead = sbuHead;
	}
public void getDetails()
{
	
}
}
