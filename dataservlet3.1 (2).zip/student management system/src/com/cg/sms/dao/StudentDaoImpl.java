package com.cg.sms.dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;

import com.cg.sms.dto.Student;

public class StudentDaoImpl implements StudentDao {
	Map<Integer, Student> studentMap;
	
public StudentDaoImpl(){
	studentMap=DataContainer.createCollection();
}
	@Override
	public int addStudent(Student student) {
	int rollno=(int) (1000*Math.random());
	student.setRollno(rollno);
	studentMap.put(rollno,student);
		// TODO Auto-generated method stub
		return rollno;
	}
	@Override
	public Student getStudent(int rn) {
		
		Student s=studentMap.get(rn);
		return s;
	}
	@Override
	public Student updateStudent(Student student) {
		
		studentMap.put(student.getRollno(),student);
		
		// TODO Auto-generated method stub
		return student;
	}
	@Override
	public ArrayList<Student> getStudent(String coursename) {
		
		Collection<Student> studList=studentMap.values();
		ArrayList<Student> students= new ArrayList<>();
		for(Student s: studList){
			if(s.getCoursename().equals(coursename))
			{
				
			students.add(s);
		}
		// TODO Auto-generated method stub
	
	
	
	

}
		return students;
}
}
