package com.cg.sms.dto;

public class Student {
	private int Rollno;
	private String Name;
	private String Coursename;
	private int Age;
	private String Mobileno;
	public int getRollno() {
		return Rollno;
	}
	public void setRollno(int rollno) {
		this.Rollno = rollno;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		this.Name = name;
	}
	public String getCoursename() {
		return Coursename;
	}
	public void setCoursename(String coursename) {
		this.Coursename = coursename;
	}
	public int getAge() {
		return Age;
	}
	public void setAge(int age) {
		this.Age = age;
	}
	public String getMobileno() {
		return Mobileno;
	}
	public void setMobileno(String mobileno) {
		this.Mobileno = mobileno;
	}
	

}
