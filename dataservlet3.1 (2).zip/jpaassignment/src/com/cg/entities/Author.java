package com.cg.entities;

public class Author {

}
