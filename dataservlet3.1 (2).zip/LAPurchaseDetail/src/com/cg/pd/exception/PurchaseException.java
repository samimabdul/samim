package com.cg.pd.exception;

public class PurchaseException extends Exception {

	private static final long serialVersionUID = 172793786022375968L;

}
