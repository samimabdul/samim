package com.cg.pd.service;

import java.util.ArrayList;

import com.cg.pd.dto.Mobile;
import com.cg.pd.dto.PurchaseDetails;

public interface PurchaseService {

public int addPurchaseDetails(PurchaseDetails pr);
	
	public ArrayList<Mobile> getMobileList();
	
	public ArrayList<Mobile> getMobileListbtw(int min, int max);
	
	public Mobile updateMobileDetsils(Mobile mob);
	
}
