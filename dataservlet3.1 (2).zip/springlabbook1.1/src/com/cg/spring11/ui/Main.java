package com.cg.spring11.ui;
import com.cg.spring11.service.*;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) {
		ApplicationContext app= new ClassPathXmlApplicationContext("springlabbook1.1.xml");
		Employee e= (Employee) app.getBean("emp");
		e.setAge(20);
		e.setBusinessUnit("java");
		e.setEmployeeId(111);
		e.setEmployeeName("sam");
		e.setSalary(11111);
		e.getDetails();
}
}