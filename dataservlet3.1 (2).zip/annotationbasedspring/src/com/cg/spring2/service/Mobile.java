package com.cg.spring2.service;

import java.util.List;

import org.springframework.stereotype.Component;
@Component("mob")
public class Mobile {

	
	
	
	int mobId;
	String mobName;
	double mobPrice;
	//Inventory ivn;
	
	
	/*public Inventory getIvn() {
		return ivn;//deleted to cteate array list
	}
	public void setIvn(Inventory ivn) {
		this.ivn = ivn;
	}*/
	
	
	public int getMobId() {
		return mobId;
	}
	public void setMobId(int mobId) {
		this.mobId = mobId;
	}
	public double getMobPrice() {
		return mobPrice;
	}
	public void setMobPrice(double mobPrice) {
		this.mobPrice = mobPrice;
	}
	public String getMobName() {
		return mobName;
	}
	public void setMobName(String mobName) {
		this.mobName = mobName;
	}
	public void printDetails() {
		//System.out.println("Id is:   "+mobId+"\nName is:  "+mobName+"\nPrice is: " +mobPrice);
		System.out.println("in mobile data....");
	}	
}
