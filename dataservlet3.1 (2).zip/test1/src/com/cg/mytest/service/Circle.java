package com.cg.mytest.service;

public class Circle implements Shape {

	@Override
	public void getShape() {
		System.out.println("in the circle");// TODO Auto-generated method stub
		
	}

}
