package com.cg.client;

public class Client {

}
