package com.cg.mps.exception;

public class PurchaseException extends Exception {

	public PurchaseException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
