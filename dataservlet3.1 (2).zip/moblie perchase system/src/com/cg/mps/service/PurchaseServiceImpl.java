package com.cg.mps.service;

import java.util.ArrayList;

import com.cg.mps.dao.PurchaseDAO;
import com.cg.mps.dao.PurchaseDAOImpl;
import com.cg.mps.dto.Mobile;
import com.cg.mps.dto.PurchaseDetails;
import com.cg.mps.exception.PurchaseException;

public class PurchaseServiceImpl implements PurchaseService  {

	PurchaseDAO dao;
	
	
	public PurchaseServiceImpl() throws PurchaseException {
		try{
		dao=new PurchaseDAOImpl();
		}catch(PurchaseException e){
			e.printStackTrace();
		}
		}
		// TODO Auto-generated constructor stub
	

	@Override
	public int addPurchaseDetails(PurchaseDetails pr) {
		// TODO Auto-generated method stub
		return dao.addPurchaseDetails(pr);
	}

	@Override
	public ArrayList<Mobile> getMobileList() {
		// TODO Auto-generated method stub
		return dao.getMobileList();
	}

	@Override
	public ArrayList<Mobile> getMobileList(int min, int max) {
		// TODO Auto-generated method stub
		return dao.getMobileList(min, max);
	}

	@Override
	public Mobile updateMobileDetails(Mobile mob) {
		// TODO Auto-generated method stub
		return dao.updateMobileDetails(mob);
	}

}
