package com.cg.mps.ui;

import java.util.ArrayList;
import java.util.Scanner;

import com.cg.mps.dto.Mobile;
import com.cg.mps.dto.PurchaseDetails;
import com.cg.mps.exception.PurchaseException;
import com.cg.mps.service.PurchaseService;
import com.cg.mps.service.PurchaseServiceImpl;


public class Main 
{
    public static void main(String[] args) throws PurchaseException 
    {
        PurchaseService service=new PurchaseServiceImpl();
       
        int ch;
        do
        {
            Scanner sc=new Scanner(System.in);
            System.out.println("1.Add customer and purchase information.");
            System.out.println("2.Display list of mobiles");
            System.out.println("3.Display list based on price range");
            System.out.println("Enter choice");
            
            ch=sc.nextInt();
            
            
            switch(ch)
            {
                case 1:
                    System.out.println("Enter name:");
                    String custName=sc.next();
                    System.out.println("Enter email id:");
                    String mailID=sc.next();
                    System.out.println("Enter contact number:");
                    String Mobileno=sc.next();
                    System.out.println("Enter desired mobile id:");
                    String mobileID=sc.next();
                    PurchaseDetails pr=new PurchaseDetails();
                    
                    pr.setCustName(custName);
                    pr.setMailId(mailID);
                    pr.setMobileno(Mobileno);
                    pr.setMobileId(mobileID);
                    
                    int pid=service.addPurchaseDetails(pr);
                    System.out.println("Purchase id is:"+pid);
                    break;
                    
                case 2:
                    System.out.println("The list of available mobiles are:");
                    mobileID=sc.next();
                	ArrayList<Mobile> list=service.getMobileList();
                	if(list.size()==0)
                	{
                	
                	System.out.println("no mobile is there");
                	
                	}
                	else
                	{
                	for(Mobile mob: list)
                	{
                		System.out.println(mob.getName()+ ""+ mob.getMobileId());//end of switch
                	}
                	}
                    
                  
                    break;
                    
                case 3:
                    System.out.println("Enter minimum price:");
                    int min=sc.nextInt();
                    System.out.println("Enter maximum price");
                    int max=sc.nextInt();
                    //service.getMobileList(min,max);
                    
            }
        
        
        }while(ch!=4);
        
        System.out.println("End of program");
            
    }
}
//switchcase