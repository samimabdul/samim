package com.cg.spring2.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.spring2.dao.IMobileDao;

@Service("mobileservice")
public class IMobileServiceImpl implements IMobileService {
    @Autowired
	IMobileDao mobiledao;
	@Override
	public void getAllMobile() {
		// TODO Auto-generated method stub
		System.out.println("in service");
		mobiledao.getAllDaoMobile();
		
	}

}
