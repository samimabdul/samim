package com.cg.spring2.dao;

public interface IMobileDao {
public void getAllDaoMobile() ;
}
