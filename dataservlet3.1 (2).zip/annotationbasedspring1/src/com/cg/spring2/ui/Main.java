package com.cg.spring2.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.spring2.service.IMobileServiceImpl;



public class Main {

	public static void main(String[] args) {
	
		@SuppressWarnings("resource")
		ApplicationContext app= new ClassPathXmlApplicationContext("Spring2.xml");
		IMobileServiceImpl mob=(IMobileServiceImpl) app.getBean("mobileservice");
		mob.getAllMobile();
	}

}
