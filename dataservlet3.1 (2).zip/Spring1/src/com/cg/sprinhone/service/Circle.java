package com.cg.sprinhone.service;

public class Circle  {
	String redious;// instance variable
	
	

	/*public String getRedious() {
		return redious;
	}*/



	public void setRedious(String redious) {
		this.redious = redious;
	}




}
