package com.cg.sprinhone.service;

public interface Shape {
               
	public void getShape();
}
