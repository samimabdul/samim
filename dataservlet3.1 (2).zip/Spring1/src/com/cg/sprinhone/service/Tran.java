package com.cg.sprinhone.service;

public class Tran implements Shape {

	String sides;
	/*public String getSides() {
		return sides;
	}*/
	public void setSides(String sides) {
		this.sides = sides;
	}
	@Override
	public void getShape() {
		System.out.println("in the Trun.....:  " +sides);// TODO Auto-generated method stub
		
	}

}
