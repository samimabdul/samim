package com.cg.exception;

@SuppressWarnings("serial")
public class invalidnumberexception extends RuntimeException {

}
