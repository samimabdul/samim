package com.cg.mobshop.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import com.cg.mobshop.dto.Mobile;
import com.cg.mobshop.dto.PurchaseDetails;
import com.cg.mobshop.exception.PurchaseException;

public class PurchaseDetailsDaoImpl  implements PurchaseDAO{

	EntityManager manager;
	Connection connection;
	public PurchaseDetailsDaoImpl() throws PurchaseException{
	EntityManagerFactory emf= Persistence.createEntityManagerFactory("JPA-PU");
	manager=emf.createEntityManager();
	}
	@Override
	public int addPurchaseDetails(PurchaseDetails pr) throws PurchaseException {

manager.getTransaction().begin();
manager.persist(pr);
manager.getTransaction().commit();
		return pr.getPurchaseId();
	}
	@Override
	public List<Mobile> getMobileList() {
		List<Mobile> list= new ArrayList<>();
		TypedQuery<Mobile> qry=manager.createQuery("select p from mobiles p",Mobile.class);
		list=qry.getResultList();
		return list;
	}
	@Override
	public ArrayList<Mobile> getMobileList(int min, int max) {
		
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public Mobile updateMobileDetails(Mobile mob) {
		
	
		return null;
	}

}











