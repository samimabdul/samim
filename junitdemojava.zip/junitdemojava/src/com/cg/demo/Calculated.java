package com.cg.demo;

import com.cg.exception.invalidnumberexception;
import com.cg.exception.negitivenumberexception;

public class Calculated {

	public int addDigits(int r) throws negitivenumberexception, invalidnumberexception {
		
		if(r<0)
		 throw new negitivenumberexception();
		
		if(r>999)
			 throw new invalidnumberexception();
		
		
		if(r<100)
			 throw new invalidnumberexception();
		
		int total=r%10;
		r=r/10;
		total=total+(r%10);
		r=r/10;
		total=total+r;
		return total;
		
	}



}
