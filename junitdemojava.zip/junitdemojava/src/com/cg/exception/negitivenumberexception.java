package com.cg.exception;

@SuppressWarnings("serial")
public class negitivenumberexception extends RuntimeException {

}
