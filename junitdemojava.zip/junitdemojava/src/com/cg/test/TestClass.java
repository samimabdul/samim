package com.cg.test;

import junit.framework.Assert;

import org.junit.Test;

import com.cg.demo.Calculated;
import com.cg.exception.invalidnumberexception;
import com.cg.exception.negitivenumberexception;

public class TestClass {
	@Test
	public void test1()
	{
		Calculated cal= new Calculated();
		int r=cal.addDigits(127);
		Assert.assertEquals(10,r);
	}
	
	@Test(expected=negitivenumberexception.class)
	public void test2()
	{
		Calculated c= new Calculated();
		c.addDigits(-127);
	}
	@Test(expected=invalidnumberexception.class)
	public void test3()
	{
		Calculated c= new Calculated();
		c.addDigits(1111127);
	}


}
