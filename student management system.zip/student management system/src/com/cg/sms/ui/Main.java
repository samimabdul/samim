package com.cg.sms.ui;

import java.util.ArrayList;
import java.util.Scanner;

import com.cg.sms.dto.Student;
import com.cg.sms.service.StudentService;
import com.cg.sms.service.StudentServiceImpl;

public class Main {
public static void main(String[] args)
{
	
	StudentService service= new StudentServiceImpl();
	Scanner sc=new Scanner(System.in);
	System.out.println("1 add student");
	System.out.println("2 display student details");
	System.out.println("3 update details");
	System.out.println("4 display student list");
	System.out.println("5 exit");
	System.out.println("* enter your choice");
	int ch;
	do{
    ch=sc.nextInt();
	switch(ch)
	{
case 1 :
	System.out.println("enter name:   ");
	String name=sc.next();
	System.out.println("enter course name:   ");
	String cname=sc.next();
	System.out.println("enter age:   ");
	int age=sc.nextInt();
	System.out.println("enter mobile no:   ");
	String mob=sc.next();
	Student student= new Student();
	student.setName(name);
	student.setCoursename(cname);
	student.setAge(age);
	student.setMobileno(mob);
	
	int rn=service.addStudent(student);
	System.out.println("student record added  : " + rn);
	break;
case 2:
	System.out.println( "enter roll no ");
	rn=sc.nextInt();
	student=service.getStudent(rn);
	if(student==null)
	{
		System.out.println("No record found");
	}
	else
	{
	System.out.println(student.getName());
	System.out.println(student.getAge());
	System.out.println(student.getCoursename());
	System.out.println(student.getMobileno());
	}
break;
case 3:
	System.out.println( "enter roll no ");
	rn=sc.nextInt();
	student=service.getStudent(rn);
	if(student==null)
	{
		System.out.println("No record found");
	}
	else
	{
	System.out.println("enter new mobno :");
	String mobno=sc.next();
	student.setMobileno(mobno);
	student=service.updateStudent(student);
	System.out.println("mobile no updated...");
	System.out.println(student.getName());
	System.out.println(student.getMobileno());
	
	
	}
	break;
case 4:
	System.out.println("Enter coursename:  ");
	cname=sc.next();
	ArrayList<Student> list=service.getStudent(cname);
	if(list.size()==0)
	{
	
	System.out.println("no student enrolled for this course");
	
	}
	else
	{
	for(Student s: list)
	{
		System.out.println(s.getName()+ ""+ s.getMobileno());//end of switch
	}
	}
	break;
	
	}//end of switch
	}
	while(ch!=5);
	
		
	}
	}



