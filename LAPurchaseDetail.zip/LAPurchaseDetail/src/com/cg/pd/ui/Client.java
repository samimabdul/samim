package com.cg.pd.ui;

import java.util.Scanner;

import com.cg.pd.dto.PurchaseDetails;
import com.cg.pd.service.PurchaseService;
import com.cg.pd.service.PurchaseServiceImpl;


public class Client {
	
	public static void main(String[] args) {
		
		PurchaseService service = new PurchaseServiceImpl();

		Scanner s = new Scanner(System.in);
		int ch= 0;
		
		do{
		
		System.out.println(" 1. Add Purchase Details ");
		System.out.println(" 2. Display list of mobiles ");
		System.out.println(" 3. Display Mobile List based on price range ");
		System.out.println("Enter your choice : ");
		ch = s.nextInt();
		switch (ch) {
		
		
		case 1:
			System.out.println("Enter Customer Name : ");
			String name = s.next();
			System.out.println("Enter Phone No : ");
			String phoneNo = s.next();
			System.out.println("Enter Mail ID : ");
			String mailId = s.next();
			System.out.println("Enter Mobile ID : ");
			int mobileId = s.nextInt();
			
			PurchaseDetails pd = new PurchaseDetails();
			pd.setCustName(name);
			pd.setPhoneNo(phoneNo);
			pd.setMailId(mailId);
			pd.setMobileId(mobileId);
			int pid = service.addPurchaseDetails(pd);
			System.out.println("Purchase id is "+pid);
		break;
	}

}while(ch!=4);
	}
}