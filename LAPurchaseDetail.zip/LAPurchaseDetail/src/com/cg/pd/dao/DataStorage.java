package com.cg.pd.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.pd.dto.Mobile;
import com.cg.pd.dto.PurchaseDetails;



public class DataStorage {
	
	private static Map<Integer,Mobile> mobiles ;
	public static Map<Integer,Mobile> createCollection1(){
		
		if(mobiles==null)
			mobiles = new HashMap<>();
		return mobiles;
	}
		
		
		
		private static Map<Integer,PurchaseDetails> purchases ;
		public static Map<Integer,PurchaseDetails> createCollection2(){
			
			if(purchases==null)
				purchases = new HashMap<>();
			return purchases;
}
}
