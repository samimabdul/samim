package com.cg.pd.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.cg.pd.dto.Mobile;
import com.cg.pd.dto.PurchaseDetails;
import com.cg.pd.exception.PurchaseException;

public class PurchaseDAOImpl implements PurchaseDAO {
	
	
	Connection conn;
	
	public PurchaseDAOImpl() throws PurchaseException{
		
		
			conn = DBConnection.getConnection();
	
	}
	
	public int generateId() throws SQLException{
		
		int id = 0;
		Statement stmt= conn.createStatement();
		ResultSet rs = stmt.executeQuery("select id_gen.nextval from dual");
		
		if(rs.next()){
			 id = rs.getInt(1);
			
		}
		return id;
	}
	
	@Override
	public int addPurchaseDetails(PurchaseDetails pr) throws SQLException {
		
		String sql= "insert into purchasedetails values "+"( ? , ? , ? , ? , sysdate , ? )";
		
		PreparedStatement ps = conn.prepareStatement(sql);
		
		int id = generateId();
		ps.setInt(1,id );
		ps.setString(2, pr.getCustName());
		ps.setString(3, pr.getMailId());
		ps.setString(4, pr.getPhoneNo());
		ps.setInt(5, pr.getMobileId());
		
		int rowcount = ps.executeUpdate();
		if(rowcount==1)


			return id;
		return 0;
	}

	@Override
	public ArrayList<Mobile> getMobileList() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<Mobile> getMobileListbtw(int min, int max) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Mobile updateMobileDetsils(Mobile mob) {
		// TODO Auto-generated method stub
		return null;
	}

}
