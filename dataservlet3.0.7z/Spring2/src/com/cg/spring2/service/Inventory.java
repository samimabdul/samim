package com.cg.spring2.service;

public class Inventory {

	int mobCount;
	String mobCompany;
	
	public int getMobCount() {
		return mobCount;
	}
	public void setMobCount(int mobCount) {
		this.mobCount = mobCount;
	}
	public String getMobCompany() {
		return mobCompany;
	}
	public void setMobCompany(String mobCompany) {
		this.mobCompany = mobCompany;
	}
	
	
	
}
