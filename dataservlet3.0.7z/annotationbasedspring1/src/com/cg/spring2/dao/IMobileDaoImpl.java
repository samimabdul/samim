package com.cg.spring2.dao;

import org.springframework.stereotype.Repository;

@Repository("mobiledao")

public class IMobileDaoImpl implements IMobileDao {

	@Override
	public void getAllDaoMobile() {
		// TODO Auto-generated method stub
		System.out.println("In dao");
		
	}
	

}
