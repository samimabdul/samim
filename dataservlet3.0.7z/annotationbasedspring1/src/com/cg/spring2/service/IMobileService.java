package com.cg.spring2.service;

public interface IMobileService {
	public void getAllMobile();

}
