package com.cg.mytest.service;

public class Tran implements Shape {

	@Override
	public void getShape() {
		System.out.println("in the Trun");// TODO Auto-generated method stub
		
	}

}
