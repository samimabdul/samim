package com.cg.mytest.service;

public class ShapeInfo {
public static Shape showShape(String shape){
	if(shape.equals("Cir"))
	return  new Circle();
	else	if(shape.equals("Tran"))
		return new Tran();
	else
	  return null;
	
}
}
