package com.cg.mytest.ui;

import java.util.Scanner;

import com.cg.mytest.service.Shape;
import com.cg.mytest.service.ShapeInfo;

public class Test {
public static void main(String[] args) 
{
	Scanner sc =  new Scanner(System.in);
	System.out.println("enter your choice");
	String str=sc.next();
Shape shape=ShapeInfo.showShape(str);
shape.getShape();
}
}
