package com.cg.springone.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.sprinhone.service.Mobile;
import com.cg.sprinhone.service.Shape;

public class MyApplication {
	
	
public static void main(String[] args) {
	
	
	ApplicationContext app = 
			new ClassPathXmlApplicationContext("spring.xml");
	
	
	Mobile sh=(Mobile) app.getBean("mob");
	
	sh.setMobId(1001);
	
	sh.setMobName("Nokia");
	
	sh.getAllDetails();
	
}
}
