package com.cg.springone.service;

public class SBU {
	int SbuId;
	String sbuName;
	String sbuHead;
	public int getSbuId() {
		return SbuId;
	}
	public void setSbuId(int sbuId) {
		SbuId = sbuId;
	}
	public String getSbuName() {
		return sbuName;
	}
	public void setSbuName(String sbuName) {
		this.sbuName = sbuName;
	}
	public String getSbuHead() {
		return sbuHead;
	}
	public void setSbuHead(String sbuHead) {
		this.sbuHead = sbuHead;
	}
	
	
	}


